module executor

import time
import memidle

pub fn (e InProcVjsxExecutor) select_next_lane() !VjsxExecutionLane {
	mut state := e.state
	state.mu.@lock()
	defer {
		state.mu.unlock()
	}
	if state.stopping { return error('inproc_vjsx_executor_closed') }
	if state.lanes.len == 0 {
		return error('inproc_vjsx_executor_no_lanes')
	}
	for offset in 0 .. state.lanes.len {
		idx := (state.rr_index + offset) % state.lanes.len
		if state.lanes[idx].inflight > 0 {
			continue
		}
		if !state.lanes[idx].healthy && !state.lanes[idx].dirty {
			continue
		}
		state.lanes[idx].inflight++
		memidle.begin()
		state.rr_index = (idx + 1) % state.lanes.len
		return state.lanes[idx]
	}
	return error('inproc_vjsx_executor_no_available_lane')
}

fn (e InProcVjsxExecutor) force_select_lane_by_id(lane_id string) !VjsxExecutionLane {
	if lane_id.trim_space() == '' {
		return error('inproc_vjsx_executor_lane_id_missing')
	}
	mut state := e.state
	state.mu.@lock()
	defer {
		state.mu.unlock()
	}
	if state.stopping { return error('inproc_vjsx_executor_closed') }
	for idx, lane in state.lanes {
		if lane.id != lane_id {
			continue
		}
		state.lanes[idx].inflight++
		memidle.begin()
		return state.lanes[idx]
	}
	return error('inproc_vjsx_executor_lane_not_found')
}

fn (e InProcVjsxExecutor) select_lane_by_id(lane_id string) !VjsxExecutionLane {
	if lane_id.trim_space() == '' {
		return error('inproc_vjsx_executor_lane_id_missing')
	}
	mut state := e.state
	state.mu.@lock()
	defer {
		state.mu.unlock()
	}
	if state.stopping { return error('inproc_vjsx_executor_closed') }
	for idx, lane in state.lanes {
		if lane.id != lane_id {
			continue
		}
		if state.lanes[idx].inflight > 0 {
			return error('inproc_vjsx_executor_no_available_lane')
		}
		if !state.lanes[idx].healthy && !state.lanes[idx].dirty {
			return error('inproc_vjsx_executor_no_available_lane')
		}
		state.lanes[idx].inflight++
		memidle.begin()
		state.rr_index = (idx + 1) % state.lanes.len
		return state.lanes[idx]
	}
	return error('inproc_vjsx_executor_lane_not_found')
}

pub fn (e InProcVjsxExecutor) acquire_next_lane(timeout_ms int) !VjsxExecutionLane {
	return e.acquire_next_lane_tracked(timeout_ms, false)
}

fn (e InProcVjsxExecutor) acquire_next_lane_tracked(timeout_ms int, track_http bool) !VjsxExecutionLane {
	mut waiting := false
	defer {
		if waiting {
			mut state := e.state
			state.mu.@lock()
			state.http_waiting--
			state.mu.unlock()
		}
	}

	mut remaining_ms := if timeout_ms > 0 { timeout_ms } else { 0 }
	deadline := time.sys_mono_now() + i64(remaining_ms) * 1000000
	for {
		lane := e.select_next_lane() or {
			if err.msg() != 'inproc_vjsx_executor_no_available_lane' {
				return error(err.msg())
			}
			if track_http && !waiting {
				mut state := e.state
				state.mu.@lock()
				state.http_waiting++
				state.http_queue_waits++
				state.mu.unlock()
				waiting = true
			}
			if remaining_ms <= 0 || time.sys_mono_now() >= deadline {
				if track_http {
					mut state := e.state
					state.mu.@lock()
					state.http_queue_timeouts++
					state.http_last_queue_timeout = time.now().unix()
					state.mu.unlock()
				}
				return error(err.msg())
			}
			time.sleep(time.millisecond * inproc_vjsx_lane_wait_poll_ms)
			remaining_ms -= inproc_vjsx_lane_wait_poll_ms
			continue
		}
		return lane
	}
	return error('inproc_vjsx_executor_no_available_lane')
}

fn (e InProcVjsxExecutor) acquire_lane_by_id(lane_id string, timeout_ms int) !VjsxExecutionLane {
	mut remaining_ms := if timeout_ms > 0 { timeout_ms } else { 0 }
	deadline := time.now().add(time.millisecond * remaining_ms)
	for {
		lane := e.select_lane_by_id(lane_id) or {
			if err.msg() == 'inproc_vjsx_executor_lane_not_found' {
				return error(err.msg())
			}
			if err.msg() != 'inproc_vjsx_executor_no_available_lane' {
				return error(err.msg())
			}
			if remaining_ms <= 0 || time.now() >= deadline {
				return error(err.msg())
			}
			time.sleep(time.millisecond * inproc_vjsx_lane_wait_poll_ms)
			remaining_ms -= inproc_vjsx_lane_wait_poll_ms
			continue
		}
		return lane
	}
	return error('inproc_vjsx_executor_no_available_lane')
}

pub fn (e InProcVjsxExecutor) release_lane(lane_id string) {
	if lane_id == '' {
		return
	}
	mut state := e.state
	state.mu.@lock()
	for i, lane in state.lanes {
		if lane.id != lane_id {
			continue
		}
		if state.lanes[i].inflight > 0 {
			state.lanes[i].inflight--
			memidle.end()
		}
		break
	}
	state.mu.unlock()
	e.try_schedule_websocket_mailboxes()
}
