#!/usr/bin/env python3
import os

summary_content = """# Summary

- [快速开始](快速开始.md)
- [项目概述](项目概述/项目概述.md)
- [核心概念](核心概念/核心概念.md)
- [配置指南](配置指南/配置指南.md)
- [开发指南](开发指南/开发指南.md)
- [执行器开发](执行器开发/执行器开发.md)
- [部署运维](部署运维/部署运维.md)
- [外部集成](外部集成/外部集成.md)
- [协议支持](协议支持/协议支持.md)
- [管理功能](管理功能/管理功能.md)
- [API 参考](API 参考/API 参考.md)
- [示例和最佳实践](示例和最佳实践/示例和最佳实践.md)
"""

book_src = os.path.join(os.path.dirname(__file__), '..', 'book-src')
summary_path = os.path.join(book_src, 'SUMMARY.md')

with open(summary_path, 'w', encoding='utf-8') as f:
    f.write(summary_content)

print(f"Wrote SUMMARY.md to {summary_path}")
