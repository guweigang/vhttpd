module main

import config
import crypto.sha256
import admin_state_store
import json2 as json
import os
import runtime_plan
import time

struct AdminDraftDeleteResponse {
	ok       bool
	draft_id string
}

struct AdminDraftPlanCounts {
	listeners   int
	resources   int
	engines     int
	adapters    int
	transforms  int
	policies    int
	providers   int
	pipelines   int
	relays      int
	diagnostics int
}

struct AdminDraftValidationResult {
	draft_id       string
	ok             bool
	error          string
	schema_version int
	counts         AdminDraftPlanCounts
	diagnostics    []runtime_plan.PlanDiagnostic
}

struct AdminDraftPublishResult {
	draft_id     string
	ok           bool
	error        string
	config_path  string
	path         string
	include_path string
	updated_main bool
}

struct AdminDraftMetadata {
	project_config string
	source_path    string
	include_path   string
}

struct AdminConfigFileEntry {
	parent_path         string
	relay_ids           []string
	pipeline_ids        []string
	websocket_listeners []string
	adapter_ids         []string
	engine_ids          []string
	error               string
	role                string
	path                string
	include_path        string
	exists              bool
	bytes               int
	draft_id            string
}

struct AdminConfigFileDraftResult {
	ok           bool
	error        string
	draft_id     string
	path         string
	include_path string
	entry        admin_state_store.Entry
}

struct AdminSourceFileEntry {
	role         string
	path         string
	include_path string
	language     string
	exists       bool
	bytes        int
	draft_id     string
}

struct AdminSourceFileDraftResult {
	ok           bool
	error        string
	draft_id     string
	path         string
	include_path string
	language     string
	entry        admin_state_store.Entry
}

struct AdminSourcePublishResult {
	draft_id string
	ok       bool
	error    string
	path     string
	language string
	bytes    int
}

fn (mut app App) open_admin_state_store() !admin_state_store.FileStore {
	event_log := app.control_plane.event_log.trim_space()
	root := if event_log != '' {
		os.join_path(os.dir(event_log), 'admin')
	} else {
		os.join_path('.var', 'vhttpd', 'admin')
	}
	return admin_state_store.FileStore.new(root)
}

fn admin_state_draft_id(raw string) string {
	clean := raw.trim_space()
	if clean != '' {
		return clean
	}
	return 'draft_${time.now().unix_micro()}'
}

fn (app &App) admin_state_draft_source_path() string {
	return admin_source_path_from_plan(app.admin_plan_view().plan)
}

fn admin_source_path_from_plan(plan runtime_plan.RuntimePlan) string {
	if plan.source.config_path.trim_space() != '' {
		return plan.source.config_path
	}
	return os.join_path(os.getwd(), 'admin-draft.toml')
}

fn (mut app App) admin_state_list_drafts() ![]admin_state_store.Entry {
	mut store := app.open_admin_state_store()!
	return store.list('drafts')!
}

fn (mut app App) admin_state_get_draft(id string) !admin_state_store.Entry {
	mut store := app.open_admin_state_store()!
	return store.get('drafts', id)!
}

fn (mut app App) admin_state_put_draft(id string, value string) !admin_state_store.Entry {
	draft_id := admin_state_draft_id(id)
	mut store := app.open_admin_state_store()!
	entry := store.put('drafts', draft_id, value)!
	store.append_event('admin.draft.saved', {
		'draft_id': draft_id
	}) or {}
	app.emit('admin.draft.saved', {
		'draft_id': draft_id
	})
	return entry
}

fn (mut app App) admin_state_put_draft_metadata(id string, metadata AdminDraftMetadata) ! {
	draft_id := admin_state_draft_id(id)
	mut store := app.open_admin_state_store()!
	store.put('draft_meta', draft_id, json.encode(metadata,
		escape_unicode: true
		time_as_unix:   true
	))!
}

fn (mut app App) admin_state_get_draft_metadata(id string) ?AdminDraftMetadata {
	mut store := app.open_admin_state_store() or { return none }
	entry := store.get('draft_meta', id) or { return none }
	return json.decode[AdminDraftMetadata](entry.value) or { none }
}

fn (mut app App) admin_state_delete_draft(id string) ! {
	mut store := app.open_admin_state_store()!
	store.delete('drafts', id)!
	store.delete('draft_meta', id) or {}
	store.append_event('admin.draft.deleted', {
		'draft_id': id
	}) or {}
	app.emit('admin.draft.deleted', {
		'draft_id': id
	})
}

fn (mut app App) admin_state_list_events(limit int) ![]admin_state_store.Event {
	mut store := app.open_admin_state_store()!
	return store.list_events(limit)!
}

fn (mut app App) admin_state_compile_draft(id string) !runtime_plan.RuntimePlan {
	entry := app.admin_state_get_draft(id)!
	metadata := app.admin_state_get_draft_metadata(id) or { AdminDraftMetadata{} }
	source_path := if metadata.source_path.trim_space() != '' {
		metadata.source_path
	} else {
		app.admin_state_draft_source_path()
	}
	if metadata.project_config != '' {
		return config.load_runtime_plan_with_overrides(metadata.project_config, {
			source_path: entry.value
		})!
	}
	return config.load_runtime_plan_text(entry.value, source_path)!
}

fn (mut app App) admin_state_validate_draft(id string) AdminDraftValidationResult {
	plan := app.admin_state_compile_draft(id) or {
		return AdminDraftValidationResult{
			draft_id: id
			ok:       false
			error:    err.msg()
		}
	}
	return AdminDraftValidationResult{
		draft_id:       id
		ok:             true
		schema_version: plan.source.schema_version
		counts:         admin_draft_plan_counts(plan)
		diagnostics:    plan.diagnostics
	}
}

fn (mut app App) admin_state_diff_draft(id string) !RuntimePlanReplacementPreview {
	next_plan := app.admin_state_compile_draft(id)!
	return app.preview_runtime_plan_replacement_for_plan('draft:${id}', next_plan)
}

fn (mut app App) admin_state_list_config_files() []AdminConfigFileEntry {
	return admin_config_files_at_path(app.admin_state_draft_source_path())
}

fn admin_config_files_at_path(path string) []AdminConfigFileEntry {
	config_path := os.abs_path(path)
	config_dir := os.dir(config_path)
	sources := config.runtime_config_sources(config_path) or {
		return [AdminConfigFileEntry{ role: 'main', path: config_path, exists: os.exists(config_path), error: err.msg() }]
	}
	mut files := []AdminConfigFileEntry{}
	for source in sources {
		is_main := source.path == config_path
		files << AdminConfigFileEntry{
			role:                if is_main { 'main' } else { 'include' }
			path:                source.path
			include_path:        if is_main {
				''
			} else {
				admin_state_relative_path(config_dir, source.path)
			}
			parent_path:         source.parent_path
			relay_ids:           source.relay_ids
			pipeline_ids:        source.pipeline_ids
			websocket_listeners: source.websocket_listeners
			adapter_ids:         source.adapter_ids
			engine_ids: source.engine_ids
			exists:              os.exists(source.path)
			bytes:               int(os.file_size(source.path))
			draft_id:            admin_state_config_draft_id(source.path)
		}
	}
	return files
}

fn (mut app App) admin_state_put_project_config_draft(id string, raw_path string, value string) !admin_state_store.Entry {
	if raw_path.trim_space() == '' { return app.admin_state_put_draft(id, value) }
	project_config := os.abs_path(app.admin_state_draft_source_path())
	resolved := admin_state_resolve_config_file_path(project_config, raw_path)!
	sources := config.runtime_config_sources(project_config)!
	if !sources.any(it.path == resolved.path) {
		return error('admin_config_source_not_in_project:${raw_path}')
	}
	entry := app.admin_state_put_draft(id, value)!
	app.admin_state_put_draft_metadata(entry.key, AdminDraftMetadata{
		project_config: project_config
		source_path:    resolved.path
		include_path:   resolved.include_path
	})!
	return entry
}

fn (mut app App) admin_state_open_config_file_draft(raw_path string) AdminConfigFileDraftResult {
	target := raw_path.trim_space()
	if target == '' {
		return AdminConfigFileDraftResult{
			ok:    false
			error: 'admin_config_file_path_required'
		}
	}
	config_path := app.admin_state_draft_source_path()
	resolved := admin_state_resolve_config_file_path(config_path, target) or {
		return AdminConfigFileDraftResult{
			ok:    false
			error: err.msg()
		}
	}
	text := os.read_file(resolved.path) or {
		return AdminConfigFileDraftResult{
			ok:           false
			error:        err.msg()
			path:         resolved.path
			include_path: resolved.include_path
		}
	}
	draft_id := admin_state_config_draft_id(resolved.path)
	entry := app.admin_state_put_draft(draft_id, text) or {
		return AdminConfigFileDraftResult{
			ok:           false
			error:        err.msg()
			draft_id:     draft_id
			path:         resolved.path
			include_path: resolved.include_path
		}
	}
	app.admin_state_put_draft_metadata(draft_id, AdminDraftMetadata{
		project_config: os.abs_path(config_path)
		source_path:    resolved.path
		include_path:   resolved.include_path
	}) or {}
	return AdminConfigFileDraftResult{
		ok:           true
		draft_id:     draft_id
		path:         resolved.path
		include_path: resolved.include_path
		entry:        entry
	}
}

fn (mut app App) admin_state_list_source_files() []AdminSourceFileEntry {
	return admin_source_files_from_plan(app.admin_plan_view().plan)
}

fn admin_source_files_from_plan(plan runtime_plan.RuntimePlan) []AdminSourceFileEntry {
	config_path := os.abs_path(admin_source_path_from_plan(plan))
	config_dir := os.dir(config_path)
	repo_root := admin_state_repo_root(config_path)
	mut files := []AdminSourceFileEntry{}
	mut seen := map[string]bool{}
	for file in admin_config_files_at_path(config_path) {
		files << admin_state_source_file_entry(repo_root, file.role, file.path, file.include_path)
		seen[os.abs_path(file.path)] = true
	}
	for _, engine in plan.engines {
		entry := engine.options.strings['entry'].trim_space()
		if entry == '' {
			continue
		}
		module_root := engine.options.strings['module_root'].trim_space()
		resolved := admin_state_resolve_engine_source_path(config_dir, module_root, entry)
		if resolved == '' || seen[resolved] || !admin_state_source_file_allowed(resolved) {
			continue
		}
		files << admin_state_source_file_entry(repo_root, 'typescript', resolved, admin_state_relative_path(config_dir,
			resolved))
		seen[resolved] = true
	}
	return files
}

fn (mut app App) admin_state_open_source_file_draft(raw_path string) AdminSourceFileDraftResult {
	resolved := app.admin_state_resolve_source_file_path(raw_path) or {
		return AdminSourceFileDraftResult{
			ok:    false
			error: err.msg()
		}
	}
	text := os.read_file(resolved.path) or {
		return AdminSourceFileDraftResult{
			ok:           false
			error:        err.msg()
			path:         resolved.path
			include_path: resolved.include_path
			language:     admin_state_source_language(resolved.path)
		}
	}
	repo_root := admin_state_repo_root(app.admin_state_draft_source_path())
	draft_id := admin_state_source_draft_id(repo_root, resolved.path)
	entry := app.admin_state_put_draft(draft_id, text) or {
		return AdminSourceFileDraftResult{
			ok:           false
			error:        err.msg()
			draft_id:     draft_id
			path:         resolved.path
			include_path: resolved.include_path
			language:     admin_state_source_language(resolved.path)
		}
	}
	app.admin_state_put_draft_metadata(draft_id, AdminDraftMetadata{
		source_path:  resolved.path
		include_path: resolved.include_path
	}) or {}
	return AdminSourceFileDraftResult{
		ok:           true
		draft_id:     draft_id
		path:         resolved.path
		include_path: resolved.include_path
		language:     admin_state_source_language(resolved.path)
		entry:        entry
	}
}

fn (mut app App) admin_state_publish_source_draft(id string, raw_path string) AdminSourcePublishResult {
	metadata := app.admin_state_get_draft_metadata(id) or { AdminDraftMetadata{} }
	target := if raw_path.trim_space() != '' {
		raw_path.trim_space()
	} else {
		metadata.source_path.trim_space()
	}
	if target == '' {
		return AdminSourcePublishResult{
			draft_id: id
			ok:       false
			error:    'admin_source_publish_path_required'
		}
	}
	resolved := app.admin_state_resolve_source_file_path(target) or {
		return AdminSourcePublishResult{
			draft_id: id
			ok:       false
			error:    err.msg()
		}
	}
	entry := app.admin_state_get_draft(id) or {
		return AdminSourcePublishResult{
			draft_id: id
			ok:       false
			error:    err.msg()
			path:     resolved.path
			language: admin_state_source_language(resolved.path)
		}
	}
	if metadata.project_config != '' {
		if resolved.path != metadata.source_path || os.abs_path(app.admin_state_draft_source_path()) != metadata.project_config {
			return AdminSourcePublishResult{ draft_id: id, error: 'admin_config_draft_target_mismatch' }
		}
	}
	language := admin_state_source_language(resolved.path)
	config_path := app.admin_state_draft_source_path()
	deployment_lock := admin_project_write_lock(config_path) or { return AdminSourcePublishResult{draft_id:id,error:err.msg()} }
	defer { os.rmdir(deployment_lock) or {} }
	change := admin_state_snapshot_publish_target(resolved.path, entry.value) or {
		return AdminSourcePublishResult{ draft_id: id, path: resolved.path, language: language, error: err.msg() }
	}
	mut store := app.open_admin_state_store() or {
		return AdminSourcePublishResult{ draft_id: id, path: resolved.path, language: language, error: err.msg() }
	}
	// Publication and recovery share the staged transaction, including missing
	// sources. Callbacks retain immutable request data rather than borrowing App.
	store.restore_config_files([change], fn [metadata, resolved, entry] () ! {
		if metadata.project_config != '' {
			config.load_runtime_plan_with_overrides(metadata.project_config, { resolved.path: entry.value })!
		}
	}, fn [language, config_path] () ! {
		if language == 'toml' { config.load_runtime_plan_file(config_path)! }
	}) or {
		return AdminSourcePublishResult{ draft_id: id, path: resolved.path, language: language, error: err.msg() }
	}
	store.append_event('admin.source.published', {
		'draft_id': id
		'path':     resolved.path
	}) or {}
	app.emit('admin.source.published', {
		'draft_id': id
		'path':     resolved.path
	})
	return AdminSourcePublishResult{
		draft_id: id
		ok:       true
		path:     resolved.path
		language: admin_state_source_language(resolved.path)
		bytes:    entry.value.len
	}
}

fn (mut app App) admin_state_publish_draft(id string, raw_path string) AdminDraftPublishResult {
	metadata := app.admin_state_get_draft_metadata(id) or { AdminDraftMetadata{} }
	target_path := if raw_path.trim_space() != '' {
		raw_path.trim_space()
	} else {
		metadata.include_path.trim_space()
	}
	if target_path == '' {
		return AdminDraftPublishResult{
			draft_id:    id
			ok:          false
			error:       'admin_draft_publish_path_required'
			config_path: app.admin_state_draft_source_path()
		}
	}
	if metadata.project_config != '' {
		result := app.admin_state_publish_source_draft(id, target_path)
		return AdminDraftPublishResult{
			draft_id: id
			ok: result.ok
			error: result.error
			config_path: metadata.project_config
			path: result.path
			include_path: metadata.include_path
		}
	}
	entry := app.admin_state_get_draft(id) or {
		return AdminDraftPublishResult{
			draft_id:    id
			ok:          false
			error:       err.msg()
			config_path: app.admin_state_draft_source_path()
		}
	}
	config_path := app.admin_state_draft_source_path()
	deployment_lock := admin_project_write_lock(config_path) or { return AdminDraftPublishResult{draft_id:id,error:err.msg()} }
	defer { os.rmdir(deployment_lock) or {} }
	resolved := admin_state_resolve_publish_path(config_path, target_path) or {
		return AdminDraftPublishResult{
			draft_id:    id
			ok:          false
			error:       err.msg()
			config_path: config_path
		}
	}
	config.load_runtime_plan_text(entry.value, resolved.path) or {
		return AdminDraftPublishResult{
			draft_id:     id
			ok:           false
			error:        err.msg()
			config_path:  config_path
			path:         resolved.path
			include_path: resolved.include_path
		}
	}
	main_snapshot := admin_state_snapshot_publish_target(config_path, '') or {
		return AdminDraftPublishResult{ draft_id: id, config_path: config_path, error: err.msg() }
	}
	if !main_snapshot.original_exists {
		return AdminDraftPublishResult{ draft_id: id, config_path: config_path, error: 'admin_draft_main_config_missing' }
	}
	old_main := main_snapshot.original
	new_main := admin_state_add_include_to_config(old_main, resolved.include_path)
	target_change := admin_state_snapshot_publish_target(resolved.path, entry.value) or {
		return AdminDraftPublishResult{ draft_id: id, config_path: config_path, path: resolved.path, include_path: resolved.include_path, error: err.msg() }
	}
	main_change := admin_state_store.ConfigFileRestore{ ...main_snapshot, value: new_main }
	mut store := app.open_admin_state_store() or {
		return AdminDraftPublishResult{ draft_id: id, config_path: config_path, path: resolved.path, include_path: resolved.include_path, error: err.msg() }
	}
	overrides := { config_path: new_main, resolved.path: entry.value }
	store.restore_config_files([target_change, main_change], fn [config_path, overrides] () ! {
		config.load_runtime_plan_with_overrides(config_path, overrides)!
	}, fn [config_path] () ! {
		config.load_runtime_plan_file(config_path)!
	}) or {
		return AdminDraftPublishResult{ draft_id: id, config_path: config_path, path: resolved.path, include_path: resolved.include_path, error: err.msg() }
	}
	store.append_event('admin.draft.published', {
		'draft_id':     id
		'path':         resolved.path
		'include_path': resolved.include_path
	}) or {}
	app.emit('admin.draft.published', {
		'draft_id':     id
		'path':         resolved.path
		'include_path': resolved.include_path
	})
	return AdminDraftPublishResult{
		draft_id:     id
		ok:           true
		config_path:  config_path
		path:         resolved.path
		include_path: resolved.include_path
		updated_main: new_main != old_main
	}
}

struct AdminDraftPublishPath {
	path         string
	include_path string
}

fn admin_state_resolve_publish_path(config_path string, raw_path string) !AdminDraftPublishPath {
	config_dir := os.dir(os.abs_path(config_path))
	repo_root := os.dir(config_dir)
	clean := raw_path.trim_space()
	target_abs := if os.is_abs_path(clean) {
		os.abs_path(clean)
	} else {
		os.abs_path(os.join_path(config_dir, clean))
	}
	separator := os.path_separator
	if target_abs == repo_root || !target_abs.starts_with(repo_root + separator) {
		return error('admin_draft_publish_path_outside_project:${clean}')
	}
	include_path := admin_state_relative_path(config_dir, target_abs)
	return AdminDraftPublishPath{
		path:         target_abs
		include_path: include_path
	}
}

fn admin_state_resolve_config_file_path(config_path string, raw_path string) !AdminDraftPublishPath {
	config_abs := os.abs_path(config_path)
	config_dir := os.dir(config_abs)
	clean := raw_path.trim_space()
	target_abs := if os.is_abs_path(clean) {
		os.abs_path(clean)
	} else {
		os.abs_path(os.join_path(config_dir, clean))
	}
	repo_root := os.dir(config_dir)
	separator := os.path_separator
	if target_abs != config_abs
		&& (target_abs == repo_root || !target_abs.starts_with(repo_root + separator)) {
		return error('admin_config_file_path_outside_project:${clean}')
	}
	include_path := if target_abs == config_abs {
		''
	} else {
		admin_state_relative_path(config_dir, target_abs)
	}
	return AdminDraftPublishPath{
		path:         target_abs
		include_path: include_path
	}
}

fn (app App) admin_state_resolve_source_file_path(raw_path string) !AdminDraftPublishPath {
	config_path := app.admin_state_draft_source_path()
	config_abs := os.abs_path(config_path)
	config_dir := os.dir(config_abs)
	repo_root := admin_state_repo_root(config_abs)
	clean := raw_path.trim_space()
	if clean == '' {
		return error('admin_source_file_path_required')
	}
	target_abs := if os.is_abs_path(clean) {
		os.abs_path(clean)
	} else {
		os.abs_path(os.join_path(config_dir, clean))
	}
	separator := os.path_separator
	if target_abs == repo_root || !target_abs.starts_with(repo_root + separator) {
		return error('admin_source_file_path_outside_project:${clean}')
	}
	if !admin_state_source_file_allowed(target_abs) {
		return error('admin_source_file_extension_not_allowed:${clean}')
	}
	return AdminDraftPublishPath{
		path:         target_abs
		include_path: if target_abs == config_abs {
			''
		} else {
			admin_state_relative_path(config_dir, target_abs)
		}
	}
}

fn admin_state_repo_root(config_path string) string {
	return os.dir(os.dir(os.abs_path(config_path)))
}

fn admin_state_resolve_engine_source_path(config_dir string, module_root string, entry string) string {
	if entry.trim_space() == '' {
		return ''
	}
	if os.is_abs_path(entry) {
		return os.abs_path(entry)
	}
	if module_root.trim_space() != '' {
		base := if os.is_abs_path(module_root) {
			module_root
		} else {
			os.join_path(config_dir, module_root)
		}
		return os.abs_path(os.join_path(base, entry))
	}
	return os.abs_path(os.join_path(config_dir, entry))
}

fn admin_state_relative_path(base string, target string) string {
	separator := os.path_separator
	prefix := base.trim_right(separator) + separator
	if target.starts_with(prefix) {
		return './' + target[prefix.len..]
	}
	parent := os.dir(base).trim_right(separator) + separator
	if target.starts_with(parent) {
		return '../' + target[parent.len..]
	}
	return target
}

fn admin_state_config_draft_id(path string) string {
	name := os.file_name(path)
	clean := name.trim_space().replace('.toml', '')
	suffix := sha256.hexhash(os.abs_path(path))[..12]
	return 'config.${admin_state_safe_id(clean)}.${suffix}.toml'
}

fn admin_state_source_draft_id(repo_root string, path string) string {
	separator := os.path_separator
	target := os.abs_path(path)
	prefix := repo_root.trim_right(separator) + separator
	rel := if target.starts_with(prefix) { target[prefix.len..] } else { os.file_name(target) }
	return 'source.${admin_state_safe_id(rel)}'
}

fn admin_state_source_file_entry(repo_root string, role string, path string, include_path string) AdminSourceFileEntry {
	resolved := os.abs_path(path)
	exists := os.exists(resolved)
	return AdminSourceFileEntry{
		role:         role
		path:         resolved
		include_path: include_path
		language:     admin_state_source_language(resolved)
		exists:       exists
		bytes:        if exists { int(os.file_size(resolved)) } else { 0 }
		draft_id:     admin_state_source_draft_id(repo_root, resolved)
	}
}

fn admin_state_source_file_allowed(path string) bool {
	return admin_state_source_language(path) in ['toml', 'typescript', 'javascript']
}

fn admin_state_source_language(path string) string {
	ext := os.file_ext(path).to_lower()
	if ext == '.toml' {
		return 'toml'
	}
	if ext in ['.ts', '.mts', '.cts'] {
		return 'typescript'
	}
	if ext in ['.js', '.mjs', '.cjs'] {
		return 'javascript'
	}
	return ''
}

fn admin_state_safe_id(raw string) string {
	mut out := []u8{}
	for ch in raw.to_lower().bytes() {
		if (ch >= `a` && ch <= `z`) || (ch >= `0` && ch <= `9`) {
			out << ch
			continue
		}
		if ch in [`-`, `_`, `.`] {
			out << ch
			continue
		}
		out << `_`
	}
	clean := out.bytestr().trim('_')
	if clean == '' {
		return 'config'
	}
	return clean
}



fn admin_state_add_include_to_config(text string, include_path string) string {
	needle := '"${include_path}"'
	if text.contains(needle) {
		return text
	}
	start := text.index('include = [') or { -1 }
	if start >= 0 {
		rest := text[start..]
		close_rel := rest.index(']') or { -1 }
		if close_rel >= 0 {
			close_idx := start + close_rel
			insert := '  ${needle},\n'
			return text[..close_idx] + insert + text[close_idx..]
		}
	}
	insert := 'include = [\n  ${needle},\n]\n\n'
	lines := text.split_into_lines()
	if lines.len > 0 && lines[0].trim_space().starts_with('version') {
		return lines[0] + '\n\n' + insert + lines[1..].join('\n')
	}
	return insert + text
}

// Resolve existing parent aliases (including platform temp-directory aliases)
// once, then snapshot the final entry without following a replacement symlink.
fn admin_state_snapshot_publish_target(path string, value string) !admin_state_store.ConfigFileRestore {
	absolute := os.abs_path(path)
	mut parent := os.dir(absolute)
	mut suffix := os.file_name(absolute)
	for !os.exists(parent) {
		if os.is_link(parent) { return error('admin_source_publish_symlink_parent:${parent}') }
		suffix = os.join_path(os.file_name(parent), suffix)
		next := os.dir(parent)
		if next == parent { return error('admin_source_publish_parent_missing') }
		parent = next
	}
	target := os.join_path(os.real_path(parent), suffix)
	if os.is_link(target) { return error('admin_source_publish_symlink:${path}') }
	exists := os.exists(target)
	if exists && !os.is_file(target) { return error('admin_source_publish_not_regular:${path}') }
	original := if exists { os.read_file(target)! } else { '' }
	mode := if exists { int(os.stat(target)!.mode & 0o777) } else { 0o600 }
	return admin_state_store.ConfigFileRestore{ path: target, original: original,
		original_exists: exists, value: value, mode: mode }
}

fn admin_draft_plan_counts(plan runtime_plan.RuntimePlan) AdminDraftPlanCounts {
	return AdminDraftPlanCounts{
		listeners:   plan.listeners.len
		resources:   plan.resources.len
		engines:     plan.engines.len
		adapters:    plan.adapters.len
		transforms:  plan.transforms.len
		policies:    plan.policies.len
		providers:   plan.providers.len
		pipelines:   plan.pipelines.len
		relays:      plan.relays.len
		diagnostics: plan.diagnostics.len
	}
}
