module executor

import config
import os

pub enum BuiltinLogicExecutorFactoryKind {
	noop
	socket_worker
	inproc_vjsx
	php_cgi
}

pub struct LogicExecutorConfigSurface {
pub:
	section                string
	app_entry_flag         string @[json: 'app_entry_flag']
	worker_entry_flag      string @[json: 'worker_entry_flag']
	module_root_flag       string @[json: 'module_root_flag']
	build_root_flag        string @[json: 'build_root_flag']
	signature_root_flag    string @[json: 'signature_root_flag']
	signature_include_flag string @[json: 'signature_include_flag']
	signature_exclude_flag string @[json: 'signature_exclude_flag']
	runtime_profile_flag   string @[json: 'runtime_profile_flag']
	lane_count_flag        string @[json: 'lane_count_flag']
}

// ExecutorFactory carries function pointers for executor construction,
// breaking the circular dependency with module main.
pub struct ExecutorFactory {
pub:
	new_inproc fn (VjsxRuntimeFacadeConfig) LogicExecutor @[required]
}

pub fn ExecutorFactory.new_default() ExecutorFactory {
	return ExecutorFactory{
		new_inproc: fn (cfg VjsxRuntimeFacadeConfig) LogicExecutor {
			return new_inproc_vjsx_executor(cfg)
		}
	}
}

pub struct BuiltinLogicExecutorSpec {
pub:
	kind                string
	aliases             []string
	provider            string
	logic_model         LogicExecutorModel
	worker_backend_mode WorkerBackendMode
	lifecycle           LogicExecutorLifecycle
	factory             BuiltinLogicExecutorFactoryKind
	config_surface      LogicExecutorConfigSurface
}

pub struct AdminLogicExecutorSpecSnapshot {
pub:
	kind                     string
	aliases                  []string
	logic_provider           string                     @[json: 'logic_provider']
	logic_executor_lifecycle string                     @[json: 'logic_executor_lifecycle']
	logic_executor_model     string                     @[json: 'logic_executor_model']
	worker_backend_mode      string                     @[json: 'worker_backend_mode']
	config_surface           LogicExecutorConfigSurface @[json: 'config_surface']
}

pub fn builtin_executor_spec_all() []BuiltinLogicExecutorSpec {
	return [
		BuiltinLogicExecutorSpec{
			kind:                'none'
			aliases:             ['noop', 'disabled']
			provider:            'none'
			logic_model:         .worker
			worker_backend_mode: .disabled
			lifecycle:           disabled_executor_lifecycle()
			factory:             .noop
			config_surface:      LogicExecutorConfigSurface{
				section: 'none'
			}
		},
		BuiltinLogicExecutorSpec{
			kind:                'php'
			aliases:             ['php_worker', 'php-worker']
			provider:            'php-worker'
			logic_model:         .worker
			worker_backend_mode: .required
			lifecycle:           php_worker_executor_lifecycle()
			factory:             .socket_worker
			config_surface:      LogicExecutorConfigSurface{
				section:           'php'
				app_entry_flag:    '--php-app-entry'
				worker_entry_flag: '--php-worker-entry'
			}
		},
		BuiltinLogicExecutorSpec{
			kind:                'php-cgi'
			aliases:             ['php_cgi', 'php-cgi']
			provider:            'php-cgi'
			logic_model:         .worker
			worker_backend_mode: .required
			lifecycle:           php_cgi_executor_lifecycle()
			factory:             .php_cgi
			config_surface:      LogicExecutorConfigSurface{
				section:           'php'
				app_entry_flag:    '--php-app-entry'
				worker_entry_flag: '--php-worker-entry'
			}
		},
		BuiltinLogicExecutorSpec{
			kind:                'vjsx'
			aliases:             []string{}
			provider:            'vjsx'
			logic_model:         .embedded
			worker_backend_mode: .disabled
			lifecycle:           embedded_executor_lifecycle()
			factory:             .inproc_vjsx
			config_surface:      LogicExecutorConfigSurface{
				section:                'vjsx'
				app_entry_flag:         '--vjsx-entry'
				module_root_flag:       '--vjsx-module-root'
				build_root_flag:        '--vjsx-build-root'
				signature_root_flag:    '--vjsx-signature-root'
				signature_include_flag: '--vjsx-signature-include'
				signature_exclude_flag: '--vjsx-signature-exclude'
				runtime_profile_flag:   '--vjsx-runtime-profile'
				lane_count_flag:        '--vjsx-thread-count'
			}
		},
	]
}

pub fn builtin_executor_spec_kinds() []string {
	return builtin_executor_spec_all().map(it.kind)
}

pub fn builtin_executor_spec_kinds_label() string {
	return builtin_executor_spec_kinds().join(' | ')
}

pub fn builtin_executor_spec_find(kind string) !BuiltinLogicExecutorSpec {
	for spec in builtin_executor_spec_all() {
		if spec.matches_kind(kind) {
			return spec
		}
	}
	return error('unsupported executor kind: ${kind}')
}

fn BuiltinLogicExecutorSpec.normalize_kind(raw string) string {
	return raw.trim_space().to_lower().replace('-', '_')
}

pub fn (spec BuiltinLogicExecutorSpec) matches_kind(raw string) bool {
	normalized := BuiltinLogicExecutorSpec.normalize_kind(raw)
	if normalized == spec.kind {
		return true
	}
	for alias in spec.aliases {
		if normalized == alias.replace('-', '_') {
			return true
		}
	}
	return false
}

pub fn (spec BuiltinLogicExecutorSpec) admin_snapshot() AdminLogicExecutorSpecSnapshot {
	return AdminLogicExecutorSpecSnapshot{
		kind:                     spec.kind
		aliases:                  spec.aliases.clone()
		logic_provider:           spec.provider
		logic_executor_lifecycle: spec.lifecycle.name()
		logic_executor_model:     spec.logic_model.str()
		worker_backend_mode:      spec.worker_backend_mode.str()
		config_surface:           spec.config_surface
	}
}

pub fn (spec BuiltinLogicExecutorSpec) resolve_php_runtime_config(args []string, cfg config.VhttpdConfig) !config.PhpConfig {
	if spec.factory != .socket_worker && spec.factory != .php_cgi {
		return error('builtin_logic_executor_php_runtime_config_unsupported:${spec.kind}')
	}
	mut php_cfg := cfg.php
	php_cfg.bin = config.CliArgs.string_or(args, '--php-bin', php_cfg.bin).trim_space()
	php_cfg.worker_entry = config.CliArgs.string_or(args, spec.config_surface.worker_entry_flag,
		php_cfg.worker_entry).trim_space()
	php_cfg.app_entry = config.CliArgs.string_or(args, spec.config_surface.app_entry_flag,
		php_cfg.app_entry).trim_space()
	if config.CliArgs.has(args, '--php-extension') {
		php_cfg.extensions = config.CliArgs.string_list_or(args, '--php-extension', []string{})
	}
	if config.CliArgs.has(args, '--php-arg') {
		php_cfg.args = config.CliArgs.string_list_or(args, '--php-arg', []string{})
	}
	is_cgi := spec.kind == 'php-cgi'
	php_worker_runtime_validate_config(php_cfg, is_cgi)!
	return php_cfg
}

pub fn (spec BuiltinLogicExecutorSpec) resolve_embedded_host_runtime_config(args []string, cfg config.VhttpdConfig) !config.EmbeddedHostRuntimeConfig {
	if spec.factory != .inproc_vjsx {
		return error('builtin_logic_executor_embedded_host_runtime_config_unsupported:${spec.kind}')
	}
	return config.EmbeddedHostRuntimeConfig.resolve(args, config.EmbeddedHostRuntimeConfig{
		app_entry:         cfg.vjsx.app_entry
		module_root:       cfg.vjsx.module_root
		build_root:        cfg.vjsx.build_root
		signature_root:    cfg.vjsx.signature_root
		signature_include: cfg.vjsx.signature_include.clone()
		signature_exclude: cfg.vjsx.signature_exclude.clone()
		runtime_profile:   cfg.vjsx.runtime_profile
		lane_count:        cfg.vjsx.thread_count
		max_requests:      cfg.vjsx.max_requests
		enable_fs:         cfg.vjsx.enable_fs
		enable_process:    cfg.vjsx.enable_process
		enable_network:    cfg.vjsx.enable_network
	}, config.EmbeddedHostCliOverrides{
		app_entry_flag:         spec.config_surface.app_entry_flag
		module_root_flag:       spec.config_surface.module_root_flag
		build_root_flag:        spec.config_surface.build_root_flag
		signature_root_flag:    spec.config_surface.signature_root_flag
		signature_include_flag: spec.config_surface.signature_include_flag
		signature_exclude_flag: spec.config_surface.signature_exclude_flag
		runtime_profile_flag:   spec.config_surface.runtime_profile_flag
		lane_count_flag:        spec.config_surface.lane_count_flag
	})!
}

pub fn (spec BuiltinLogicExecutorSpec) resolve_vjsx_runtime_config(args []string, cfg config.VhttpdConfig) !VjsxRuntimeFacadeConfig {
	if spec.factory != .inproc_vjsx {
		return error('builtin_logic_executor_vjsx_runtime_config_unsupported:${spec.kind}')
	}
	embedded_cfg := spec.resolve_embedded_host_runtime_config(args, cfg) or {
		match err.msg() {
			'embedded_host_missing_app_entry' {
				return error('inproc_vjsx_executor_missing_app_entry')
			}
			else {
				if err.msg().starts_with('embedded_host_app_entry_not_found:') {
					return error(err.msg().replace('embedded_host_app_entry_not_found:',
						'inproc_vjsx_executor_app_entry_not_found:'))
				}
				return error(err.msg())
			}
		}
	}
	return VjsxRuntimeFacadeConfig{
		app_entry:                  embedded_cfg.app_entry
		module_root:                embedded_cfg.module_root
		build_root:                 embedded_cfg.build_root
		signature_root:             embedded_cfg.signature_root
		signature_include:          embedded_cfg.signature_include.clone()
		signature_exclude:          embedded_cfg.signature_exclude.clone()
		runtime_profile:            embedded_cfg.runtime_profile
		thread_count:               embedded_cfg.lane_count
		max_requests:               embedded_cfg.max_requests
		enable_fs:                  embedded_cfg.enable_fs
		enable_process:             embedded_cfg.enable_process
		enable_network:             embedded_cfg.enable_network
		enable_item_render_streams: true
		websocket_affinity:         cfg.websocket_affinity
		websocket_actor:            cfg.websocket_actor
	}
}

pub fn (spec BuiltinLogicExecutorSpec) build_executor(args []string, cfg config.VhttpdConfig, factory ExecutorFactory) !LogicExecutor {
	match spec.factory {
		.noop {
			return DisabledLogicExecutor{}
		}
		.socket_worker {
			return SocketWorkerExecutor{}
		}
		.php_cgi {
			return PhpCgiExecutor{}
		}
		.inproc_vjsx {
			return factory.new_inproc(spec.resolve_vjsx_runtime_config(args, cfg)!)
		}
	}
}

pub fn (spec BuiltinLogicExecutorSpec) runtime_selection(args []string, cfg config.VhttpdConfig, factory ExecutorFactory) !ExecutorRuntimeSelection {
	return ExecutorRuntimeSelection{
		executor:            spec.build_executor(args, cfg, factory)!
		worker_backend_mode: spec.worker_backend_mode
		lifecycle:           spec.lifecycle
	}
}

// ── PHP Worker Runtime Helpers ──
// Used by lifecycle prepare_bootstrap and registry config resolution.

struct PhpWorkerRuntime {}

pub fn php_worker_runtime_shell_quote_arg(raw string) string {
	if raw == '' {
		return "''"
	}
	return "'" + raw.replace("'", '\'"\'"\'') + "'"
}

pub fn php_worker_runtime_validate_config(php_cfg config.PhpConfig, is_cgi bool) ! {
	if !is_cgi {
		worker_entry := php_cfg.worker_entry.trim_space()
		if worker_entry == '' {
			return error('php_worker_entry_missing')
		}
		if !os.exists(worker_entry) {
			return error('php_worker_entry_not_found:${worker_entry}')
		}
	}
	app_entry := php_cfg.app_entry.trim_space()
	if app_entry != '' && !os.exists(app_entry) {
		return error('php_app_entry_not_found:${app_entry}')
	}
	for ext in php_cfg.extensions {
		ext_path := ext.trim_space()
		if ext_path == '' {
			continue
		}
		if !os.exists(ext_path) {
			return error('php_extension_not_found:${ext_path}')
		}
	}
}

pub fn php_worker_runtime_build_command(php_cfg config.PhpConfig) !string {
	mut bin := php_cfg.bin.trim_space()
	if bin == '' {
		bin = 'php'
	}
	worker_entry := php_cfg.worker_entry.trim_space()
	if worker_entry == '' {
		return error('php_worker_entry_missing')
	}
	mut parts := []string{}
	parts << bin
	for ext in php_cfg.extensions {
		ext_path := ext.trim_space()
		if ext_path == '' {
			continue
		}
		parts << '-d'
		parts << 'extension=${ext_path}'
	}
	for arg in php_cfg.args {
		if arg.trim_space() == '' {
			continue
		}
		parts << arg
	}
	parts << worker_entry
	return parts.map(php_worker_runtime_shell_quote_arg(it)).join(' ')
}

pub fn php_worker_runtime_build_env(worker_env map[string]string, php_cfg config.PhpConfig) map[string]string {
	mut env := worker_env.clone()
	if php_cfg.app_entry.trim_space() != '' {
		env['VHTTPD_APP'] = php_cfg.app_entry
	}
	return env
}

pub fn php_cgi_runtime_build_command(php_cfg config.PhpConfig) !string {
	mut bin := php_cfg.bin.trim_space()
	if bin == '' || bin == 'php' {
		bin = 'php-cgi'
	}
	mut parts := []string{}
	parts << bin
	for ext in php_cfg.extensions {
		ext_path := ext.trim_space()
		if ext_path == '' {
			continue
		}
		parts << '-d'
		parts << 'extension=${ext_path}'
	}
	for arg in php_cfg.args {
		if arg.trim_space() == '' {
			continue
		}
		parts << arg
	}
	parts << '-b'
	parts << '{socket}'
	return parts.map(php_worker_runtime_shell_quote_arg(it)).join(' ')
}
