module executor

import json2 as json
import os
import time
import upstream.transport
import vjsx

struct InProcVjsxWebSocketJs {}

fn InProcVjsxWebSocketJs.write_log(ctx &vjsx.Context, meta InProcVjsxRuntimeMeta, level string, args []vjsx.Value) {
	host := ctx.js_global('vhttpdHost')
	defer { host.free() }
	callback := host.get('log')
	defer { callback.free() }
	identity := ctx.json_parse(json.encode({'requestId':meta.request_id,'traceId':meta.trace_id}))
	defer { identity.free() }
	result := ctx.call(callback,level,InProcVjsxWebSocketJs.log_args(args),identity) or { return }
	result.free()
}

fn InProcVjsxWebSocketJs.value_from_json(ctx &vjsx.Context, raw string) vjsx.Value {
	if raw.trim_space() == '' {
		return ctx.js_object()
	}
	return ctx.json_parse(raw)
}

fn InProcVjsxWebSocketJs.log_args(args []vjsx.Value) string {
	mut parts := []string{cap: args.len}
	for arg in args {
		parts << arg.to_string()
	}
	return parts.join(' ')
}

fn InProcVjsxWebSocketJs.runtime(ctx &vjsx.Context, runtime_meta InProcVjsxRuntimeMeta, runtime_config_json string, mut app EmbeddedHost) vjsx.Value {
	mut runtime := ctx.js_object()
	minimal_runtime := os.getenv('VHTTPD_VJSX_WS_MINIMAL_RUNTIME').trim_space().to_lower() in [
		'1',
		'true',
		'yes',
		'on',
	]
	mut capabilities := ctx.js_object()
	defer { capabilities.free() }
	capabilities.set('http', false)
	capabilities.set('fetch', false)
	capabilities.set('bridgeDispatch', false)
	capabilities.set('websocketUpstream', false)
	capabilities.set('websocketDispatch', true)
	capabilities.set('fs', false)
	capabilities.set('process', false)
	capabilities.set('network', false)
	runtime.set('provider', runtime_meta.provider)
	runtime.set('executor', runtime_meta.executor)
	runtime.set('dispatchKind', 'websocket')
	runtime.set('laneId', runtime_meta.lane_id)
	runtime.set('requestId', runtime_meta.request_id)
	runtime.set('traceId', runtime_meta.trace_id)
	runtime.set('appEntry', runtime_meta.app_entry)
	runtime.set('moduleRoot', runtime_meta.module_root)
	runtime.set('runtimeProfile', runtime_meta.runtime_profile)
	runtime.set('threadCount', runtime_meta.thread_count)
	runtime.set('capabilities', capabilities)
	mut request := ctx.js_object()
	defer { request.free() }
	request.set('id', runtime_meta.request_id)
	request.set('traceId', runtime_meta.trace_id)
	request.set('method', runtime_meta.method)
	request.set('path', runtime_meta.path)
	request.set('url', runtime_meta.path)
	request.set('target', runtime_meta.request_target)
	request.set('href', runtime_meta.request_target)
	request.set('origin', '')
	request.set('scheme', runtime_meta.request_scheme)
	request.set('host', runtime_meta.request_host)
	request.set('port', runtime_meta.request_port)
	request.set('protocolVersion', runtime_meta.request_protocol_version)
	request.set('remoteAddr', runtime_meta.request_remote_addr)
	request.set('ip', runtime_meta.request_remote_addr)
	server := InProcVjsxWebSocketJs.value_from_json(ctx,
		json.encode(runtime_meta.request_server, escape_unicode: true, time_as_unix: true))
	defer { server.free() }
	request.set('server', server)
	runtime.set('request', request)
	runtime.set('method', runtime_meta.method)
	runtime.set('path', runtime_meta.path)
	runtime.set('runtimeInitError', '')
	if minimal_runtime {
		return runtime
	}
	now_fn := ctx.js_function(fn [ctx] (args []vjsx.Value) vjsx.Value {
		_ = args
		return ctx.js_i64(time.now().unix_milli())
	})
	defer { now_fn.free() }
	runtime.set('now', now_fn)
	log_fn := ctx.js_function(fn [ctx, runtime_meta] (args []vjsx.Value) vjsx.Value {
		InProcVjsxWebSocketJs.write_log(ctx,runtime_meta,'info',args)
		return ctx.js_undefined()
	})
	defer { log_fn.free() }
	runtime.set('log', log_fn)
	warn_fn := ctx.js_function(fn [ctx, runtime_meta] (args []vjsx.Value) vjsx.Value {
		InProcVjsxWebSocketJs.write_log(ctx,runtime_meta,'warn',args)
		return ctx.js_undefined()
	})
	defer { warn_fn.free() }
	runtime.set('warn', warn_fn)
	error_fn := ctx.js_function(fn [ctx, runtime_meta] (args []vjsx.Value) vjsx.Value {
		InProcVjsxWebSocketJs.write_log(ctx,runtime_meta,'error',args)
		return ctx.js_undefined()
	})
	defer { error_fn.free() }
	runtime.set('error', error_fn)
	config_fn := ctx.js_function(fn [ctx, runtime_config_json] (args []vjsx.Value) vjsx.Value {
		path := if args.len > 0 { args[0].to_string().trim_space() } else { '' }
		fallback := if args.len > 1 { args[1].dup_value() } else { ctx.js_undefined() }
		raw := InProcVjsxHostApi.config_lookup(runtime_config_json, path)
		if raw.trim_space() == '' {
			return fallback
		}
		fallback.free()
		return ctx.js_string(raw)
	})
	defer { config_fn.free() }
	runtime.set('config', config_fn)
	get_config_fn := ctx.js_function(fn [ctx, runtime_config_json] (args []vjsx.Value) vjsx.Value {
		path := if args.len > 0 { args[0].to_string().trim_space() } else { '' }
		fallback := if args.len > 1 { args[1].dup_value() } else { ctx.js_undefined() }
		raw := InProcVjsxHostApi.config_lookup(runtime_config_json, path)
		if raw.trim_space() == '' {
			return fallback
		}
		fallback.free()
		return ctx.json_parse(raw)
	})
	defer { get_config_fn.free() }
	runtime.set('getConfig', get_config_fn)
	// Callbacks outlive the mutable interface argument supplied by the caller.
	callback_app := app
	plan_fn := ctx.js_function(fn [ctx, callback_app] (args []vjsx.Value) vjsx.Value {
		path := if args.len > 0 { args[0].to_string().trim_space() } else { '' }
		fallback := if args.len > 1 { args[1].dup_value() } else { ctx.js_undefined() }
		raw := InProcVjsxHostApi.config_lookup(callback_app.get_runtime_plan_json(), path)
		if raw.trim_space() == '' {
			return fallback
		}
		fallback.free()
		return ctx.js_string(raw)
	})
	defer { plan_fn.free() }
	runtime.set('plan', plan_fn)
	get_plan_fn := ctx.js_function(fn [ctx, callback_app] (args []vjsx.Value) vjsx.Value {
		path := if args.len > 0 { args[0].to_string().trim_space() } else { '' }
		fallback := if args.len > 1 { args[1].dup_value() } else { ctx.js_undefined() }
		raw := InProcVjsxHostApi.config_lookup(callback_app.get_runtime_plan_json(), path)
		if raw.trim_space() == '' {
			return fallback
		}
		fallback.free()
		return ctx.json_parse(raw)
	})
	defer { get_plan_fn.free() }
	runtime.set('getPlan', get_plan_fn)
	InProcVjsxWebSocketJs.install_session_store(ctx, mut runtime)
	InProcVjsxWebSocketJs.install_websocket_dispatch(ctx, mut runtime, mut app)
	return runtime
}

fn InProcVjsxWebSocketJs.frame(ctx &vjsx.Context, frame transport.WorkerWebSocketFrame, runtime vjsx.Value) vjsx.Value {
	mut js_frame := ctx.js_object()
	js_frame.set('mode', if frame.mode != '' { frame.mode } else { 'websocket_dispatch' })
	js_frame.set('event', if frame.event != '' { frame.event } else { 'message' })
	js_frame.set('id', frame.id)
	js_frame.set('path', frame.path)
	query := InProcVjsxWebSocketJs.value_from_json(ctx, json.encode(frame.query,
		escape_unicode: true
		time_as_unix:   true
	))
	defer { query.free() }
	js_frame.set('query', query)
	headers := InProcVjsxWebSocketJs.value_from_json(ctx, json.encode(frame.headers,
		escape_unicode: true
		time_as_unix:   true
	))
	defer { headers.free() }
	js_frame.set('headers', headers)
	js_frame.set('remoteAddr', frame.remote_addr)
	js_frame.set('requestId', frame.request_id)
	js_frame.set('traceId', frame.trace_id)
	js_frame.set('targetId', frame.target_id)
	metadata := InProcVjsxWebSocketJs.value_from_json(ctx, json.encode(frame.metadata,
		escape_unicode: true
		time_as_unix:   true
	))
	defer { metadata.free() }
	js_frame.set('metadata', metadata)
	js_frame.set('status', frame.status)
	js_frame.set('code', frame.code)
	js_frame.set('reason', frame.reason)
	js_frame.set('opcode', frame.opcode)
	js_frame.set('data', frame.data)
	js_frame.set('error', frame.error)
	js_frame.set('errorClass', frame.error_class)
	js_frame.set('runtime', runtime)
	return js_frame
}
