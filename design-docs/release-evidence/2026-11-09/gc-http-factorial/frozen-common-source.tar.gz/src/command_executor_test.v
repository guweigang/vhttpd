module main

import command
import config
import upstream.transport
import provider
import executor as execmod
import feishu
import codex
import ws

fn test_normalized_command_from_worker_command_codex_rpc_send() {
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:     'codex.rpc.send'
		stream_id: 'codex:task_001'
		method:    'thread/start'
		params:    '{"cwd":"/tmp/demo"}'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	assert normalized.version == '1'
	assert normalized.kind == 'provider.rpc.call'
	assert normalized.provider == 'codex'
	assert normalized.correlation.stream_id == 'codex:task_001'
	assert normalized.correlation.task_id == 'task_001'
	assert normalized.method == 'thread/start'
}

fn test_normalized_command_from_worker_command_feishu_patch() {
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:     'feishu.message.patch'
		target:    'om_xxx'
		stream_id: 'codex:task_002'
		text:      'chunk'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	assert normalized.kind == 'stream.append'
	assert normalized.provider == 'feishu'
	assert normalized.target.id == 'om_xxx'
	assert normalized.correlation.stream_id == 'codex:task_002'
	assert normalized.text == 'chunk'
}

fn test_command_route_from_normalized_provider_message_send_for_feishu() {
	$if no_feishu_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'feishu'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'feishu.message.'
			},
		]
		route_kind:       .feishu
		provider:         FeishuProvider{}
		handler:          FeishuCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:    'provider.message.send'
		provider: 'feishu'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.feishu
}

fn test_command_route_from_normalized_stream_append_for_feishu() {
	$if no_feishu_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'feishu'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'feishu.message.'
			},
		]
		route_kind:       .feishu
		provider:         FeishuProvider{}
		handler:          FeishuCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:    'stream.append'
		provider: 'feishu'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.feishu
}

fn test_command_route_from_normalized_stream_fail_for_feishu() {
	$if no_feishu_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'feishu'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'feishu.message.'
			},
		]
		route_kind:       .feishu
		provider:         FeishuProvider{}
		handler:          FeishuCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:    'stream.fail'
		provider: 'feishu'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.feishu
}

fn test_execute_provider_instance_upsert_applies_feishu_app_config() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			feishu:   feishu.FeishuState{
				apps:    map[string]config.FeishuAppConfig{}
				runtime: map[string]feishu.ProviderRuntime{}
			}
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	mut exec := command.CommandExecutor.new(app.build_command_context())
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	normalized := command.NormalizedCommand{
		kind:          'provider.instance.upsert'
		provider:      'feishu'
		instance:      'main'
		config_raw:    '{"app_id":"bot_app","app_secret":"bot_secret"}'
		desired_state: 'connected'
	}
	handled, exec_err := exec.execute_instance_command(normalized, mut snapshot)
	assert handled
	assert exec_err == ''
	assert snapshot.status == 'upserted'
	assert app.providers.feishu.apps['main'].app_id == 'bot_app'
	assert app.providers.feishu.apps['main'].app_secret == 'bot_secret'
}

fn test_command_route_from_command_codex_control() {
	$if no_codex_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'codex'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'codex.'
			},
		]
		route_kind:       .codex
		provider:         CodexProvider{}
		handler:          CodexCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'codex.rpc.send'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.codex
}

fn test_command_route_from_command_feishu_message_prefix() {
	$if no_feishu_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'feishu'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'feishu.message.'
			},
		]
		route_kind:       .feishu
		provider:         FeishuProvider{}
		handler:          FeishuCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'feishu.message.patch'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.feishu
}

fn test_command_route_from_command_generic_fallback() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'discord.message.send'
		event: 'send'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.generic
}

fn test_command_route_from_command_ollama_message_prefix() {
	$if no_ollama_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'ollama'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'ollama.message.'
			},
		]
		route_kind:       .ollama
		provider:         OllamaProvider{}
		handler:          GenericUpstreamCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'ollama.message.send'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.ollama
}

fn test_provider_spec_command_matchers_are_exposed_in_snapshot() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	app.register_provider_spec(ProviderSpec{
		lifecycle_ctx:    provider.RuntimeContext.noop()
		name:             'feishu'
		enabled:          true
		has_handler:      true
		has_runtime:      true
		command_matchers: [
			provider.CommandMatcher{
				kind:  provider.CommandMatcherKind.prefix
				value: 'feishu.message.'
			},
		]
		route_kind:       .feishu
		provider:         FeishuProvider{}
		handler:          FeishuCommandHandler.new(mut app)
		runtime:          NoopProviderRuntime{}
	})
	snap := app.admin_provider_specs_snapshot()
	assert snap.len == 1
	assert snap[0].command_matchers.len == 1
	assert snap[0].command_matchers[0] == 'prefix:feishu.message.'
	assert snap[0].route_kind == 'feishu'
}

fn test_command_matcher_exact_kind_matches_exactly() {
	matcher := provider.CommandMatcher{
		kind:  provider.CommandMatcherKind.exact
		value: 'codex.rpc.send'
	}
	assert matcher.matches('codex.rpc.send')
	assert !matcher.matches('codex.rpc.reply')
}

fn test_command_executor_feishu_route_enabled_default_true() {
	$if no_feishu_routes ? {
		return
	}
	assert command.CommandExecutor.feishu_route_enabled() == true
}

fn test_command_route_from_command_feishu_is_generic_when_disabled() {
	$if !no_feishu_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'feishu.message.patch'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.generic
	assert command.CommandExecutor.feishu_route_enabled() == false
}

fn test_codex_handler_non_codex_command_not_handled() {
	$if no_codex_routes ? {
		return
	}
	mut app := &App{}
	mut handler := CodexCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'feishu.message.send'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == false
	assert err == ''
}

fn test_command_executor_codex_route_enabled_default_true() {
	$if no_codex_routes ? {
		return
	}
	assert command.CommandExecutor.codex_route_enabled() == true
}

fn test_command_executor_ollama_route_enabled_default_true() {
	$if no_ollama_routes ? {
		return
	}
	assert command.CommandExecutor.ollama_route_enabled() == true
}

fn test_command_route_from_command_codex_is_generic_when_disabled() {
	$if !no_codex_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'codex.rpc.send'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.generic
	assert command.CommandExecutor.codex_route_enabled() == false
}

fn test_command_route_from_command_ollama_is_generic_when_disabled() {
	$if !no_ollama_routes ? {
		return
	}
	mut app := &App{
		providers: ProviderRuntimeHub{
			registry: ProviderHost{
				specs: map[string]ProviderSpec{}
			}
		}
	}
	mut exec := command.CommandExecutor.new(app.build_command_context())
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'ollama.message.send'
		event: 'send'
	}
	assert exec.route_from_specs(cmd) == provider.ProviderRouteKind.generic
	assert command.CommandExecutor.ollama_route_enabled() == false
}

fn test_feishu_handler_non_feishu_command_not_handled() {
	mut app := &App{}
	mut handler := FeishuCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'codex.rpc.send'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == false
	assert err == ''
}

fn test_feishu_command_normalize_stream_send_only_applies_to_stream_commands() {
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'feishu.message.send'
	}
	req := ws.UpstreamSendRequest{
		provider:     'feishu'
		message_type: 'text'
		text:         'plain'
	}
	normalized_cmd := command.NormalizedCommand.from_worker_command(cmd)
	normalized := req.normalize_feishu_streaming_for(normalized_cmd)
	assert normalized.message_type == 'text'
	assert normalized.text == 'plain'
}

fn test_feishu_command_normalize_stream_send_promotes_stream_send_to_interactive() {
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:     'feishu.message.send'
		stream_id: 'stream_123'
	}
	req := ws.UpstreamSendRequest{
		provider:     'feishu'
		message_type: 'text'
		text:         'stream body'
	}
	normalized_cmd := command.NormalizedCommand.from_worker_command(cmd)
	normalized := req.normalize_feishu_streaming_for(normalized_cmd)
	assert normalized.message_type == 'interactive'
	assert normalized.content.contains('stream body')
}

fn test_generic_handler_executes_admin_worker_restart_all_command() {
	mut app := &App{}
	mut handler := GenericUpstreamCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_: 'admin.worker.restart_all'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'restarted'
	assert snapshot.provider == 'admin'
	assert snapshot.event == 'restart_all'
}

fn test_websocket_upstream_request_from_normalized_uses_default_provider_and_fields() {
	normalized := command.NormalizedCommand{
		instance:     'main'
		target:       command.CommandTarget{
			id:    'oc_123'
			type_: 'chat_id'
		}
		message_type: 'text'
		content:      '{"text":"hello"}'
		text:         'hello'
		uuid:         'uuid_123'
		method:       'thread/start'
		params:       '{"cwd":"/tmp/demo"}'
		metadata:     {
			'trace_id': 'trace_001'
		}
	}
	req := ws.UpstreamSendRequest.from_normalized(normalized, 'discord')
	assert req.provider == 'discord'
	assert req.instance == 'main'
	assert req.target == 'oc_123'
	assert req.target_type == 'chat_id'
	assert req.message_type == 'text'
	assert req.content == '{"text":"hello"}'
	assert req.text == 'hello'
	assert req.uuid == 'uuid_123'
	assert req.method == 'thread/start'
	assert req.params == '{"cwd":"/tmp/demo"}'
	assert req.metadata['trace_id'] == 'trace_001'
}

fn test_websocket_upstream_request_from_normalized_prefers_declared_provider() {
	normalized := command.NormalizedCommand{
		provider: 'ollama'
	}
	req := ws.UpstreamSendRequest.from_normalized(normalized, 'generic')
	assert req.provider == 'ollama'
}

fn test_command_executor_handles_provider_instance_upsert() {
	mut app := &App{}
	mut executor := command.CommandExecutor.new(app.build_command_context())
	commands := [
		transport.WorkerWebSocketUpstreamCommand{
			type_:    'provider.instance.upsert'
			provider: 'codex'
			instance: 'project_demo'
			content:  '{"url":"ws://127.0.0.1:4500","model":"gpt-5.4"}'
			metadata: {
				'desired_state': 'connected'
			}
		},
	]
	snapshots, last_error := executor.execute_commands('unit-upsert', commands)
	assert last_error == ''
	assert snapshots.len == 1
	assert snapshots[0].status == 'upserted'
	spec := app.provider_instance_get('codex', 'project_demo') or {
		panic('missing provider instance spec')
	}
	assert spec.provider == 'codex'
	assert spec.instance == 'project_demo'
	assert spec.desired_state == 'connected'
	assert spec.config_json.contains('"model":"gpt-5.4"')
}

fn test_codex_handler_session_bind_thread_updates_runtime_binding() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			codex: codex.CodexState{
				runtime: codex.ProviderRuntime{
					thread_stream_map: map[string]string{}
					stream_map:        map[string][]codex.CodexTarget{}
				}
			}
		}
	}
	mut handler := CodexCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:       'session.bind'
		provider:    'codex'
		stream_id:   'codex:task_001'
		target:      'thread_001'
		target_type: 'thread_id'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'bound'
	assert app.providers.codex.runtime.thread_id == 'thread_001'
	assert app.providers.codex.runtime.thread_stream_map['thread_001'] == 'codex:task_001'
}

fn test_codex_handler_session_clear_thread_removes_runtime_binding() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			codex: codex.CodexState{
				runtime: codex.ProviderRuntime{
					thread_id:         'thread_001'
					thread_stream_map: {
						'thread_001': 'codex:task_001'
					}
					stream_map:        map[string][]codex.CodexTarget{}
				}
			}
		}
	}
	mut handler := CodexCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:       'session.clear'
		provider:    'codex'
		target:      'thread_001'
		target_type: 'thread_id'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'cleared'
	assert app.providers.codex.runtime.thread_id == ''
	assert 'thread_001' !in app.providers.codex.runtime.thread_stream_map
}

fn test_feishu_handler_session_bind_message_registers_stream_target_and_buffer() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			codex:  codex.CodexState{
				runtime: codex.ProviderRuntime{
					thread_stream_map: map[string]string{}
					stream_map:        map[string][]codex.CodexTarget{}
				}
			}
			feishu: feishu.FeishuState{
				buffers: map[string]feishu.StreamBuffer{}
			}
		}
	}
	lease := app.providers.feishu.issue_wire_bind_creation('codex:task_002', 'main', 'om_reply_001') or { panic(err) }
	mut handler := FeishuCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		type_:       'session.bind'
		provider:    'feishu'
		instance:    'main'
		stream_id:   'codex:task_002'
		target:      'om_reply_001'
		target_type: 'message_id'
		metadata:    {
			'creation_generation': lease.generation
			'creation_token':      lease.token
		}
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'bound'
	assert snapshot.message_id == 'om_reply_001'
	assert app.providers.codex.runtime.stream_map['codex:task_002'].len == 1
	assert app.providers.codex.runtime.stream_map['codex:task_002'][0].message_id == 'om_reply_001'
	assert 'om_reply_001' in app.providers.feishu.buffers
	assert app.providers.feishu.buffers['om_reply_001'].stream_id == 'codex:task_002'
}

fn test_feishu_handler_session_clear_message_removes_buffer_and_stream_target() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			codex:  codex.CodexState{
				runtime: codex.ProviderRuntime{
					thread_stream_map: map[string]string{}
					stream_map:        {
						'codex:task_003': [
							codex.CodexTarget{
								platform:   'feishu'
								message_id: 'om_reply_002'
							},
						]
					}
				}
			}
			feishu: feishu.FeishuState{
				buffers: {
					'om_reply_002': feishu.StreamBuffer{
						generation: 'fixture'
						message_id: 'om_reply_002'
						stream_id:  'codex:task_003'
					}
				}
			}
		}
	}
	mut handler := FeishuCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		metadata:    {
			'stream_generation': 'fixture'
		}
		type_:       'session.clear'
		provider:    'feishu'
		stream_id:   'codex:task_003'
		target:      'om_reply_002'
		target_type: 'message_id'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'cleared'
	assert 'om_reply_002' !in app.providers.feishu.buffers
	assert 'codex:task_003' !in app.providers.codex.runtime.stream_map
}

fn test_feishu_handler_session_clear_message_removes_buffer_chain() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			codex:  codex.CodexState{
				runtime: codex.ProviderRuntime{
					thread_stream_map: map[string]string{}
					stream_map:        {
						'codex:task_chain': [
							codex.CodexTarget{
								platform:   'feishu'
								message_id: 'om_chain_1'
							},
							codex.CodexTarget{
								platform:   'feishu'
								message_id: 'om_chain_2'
							},
						]
					}
				}
			}
			feishu: feishu.FeishuState{
				buffers: {
					'om_chain_1': feishu.StreamBuffer{
						generation:      'fixture'
						message_id:      'om_chain_1'
						stream_id:       'codex:task_chain'
						next_message_id: 'om_chain_2'
					}
					'om_chain_2': feishu.StreamBuffer{
						generation: 'fixture'
						message_id: 'om_chain_2'
						stream_id:  'codex:task_chain'
					}
				}
			}
		}
	}
	mut handler := FeishuCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		metadata:    {
			'stream_generation': 'fixture'
		}
		type_:       'session.clear'
		provider:    'feishu'
		target:      'om_chain_1'
		target_type: 'message_id'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'cleared'
	assert 'om_chain_1' !in app.providers.feishu.buffers
	assert 'om_chain_2' !in app.providers.feishu.buffers
	assert 'codex:task_chain' !in app.providers.codex.runtime.stream_map
}

fn test_feishu_handler_session_clear_stream_id_removes_all_stream_buffers() {
	mut app := &App{
		providers: ProviderRuntimeHub{
			codex:  codex.CodexState{
				runtime: codex.ProviderRuntime{
					thread_stream_map: map[string]string{}
					stream_map:        {
						'codex:task_stream_clear': [
							codex.CodexTarget{
								platform:   'feishu'
								message_id: 'om_stream_1'
							},
							codex.CodexTarget{
								platform:   'feishu'
								message_id: 'om_stream_2'
							},
						]
					}
				}
			}
			feishu: feishu.FeishuState{
				buffers: {
					'om_stream_1': feishu.StreamBuffer{
						generation: 'fixture'
						message_id: 'om_stream_1'
						stream_id:  'codex:task_stream_clear'
					}
					'om_stream_2': feishu.StreamBuffer{
						generation: 'fixture'
						message_id: 'om_stream_2'
						stream_id:  'codex:task_stream_clear'
					}
					'om_other':    feishu.StreamBuffer{
						generation: 'fixture'
						message_id: 'om_other'
						stream_id:  'codex:other'
					}
				}
			}
		}
	}
	mut handler := FeishuCommandHandler.new(mut app)
	cmd := transport.WorkerWebSocketUpstreamCommand{
		metadata:  {
			'stream_generation': 'fixture'
		}
		type_:     'session.clear'
		provider:  'feishu'
		stream_id: 'codex:task_stream_clear'
	}
	normalized := command.NormalizedCommand.from_worker_command(cmd)
	mut snapshot := execmod.WebSocketUpstreamCommandActivity{}
	handled, err := handler.execute(cmd, normalized, mut snapshot)
	assert handled == true
	assert err == ''
	assert snapshot.status == 'cleared'
	assert 'om_stream_1' !in app.providers.feishu.buffers
	assert 'om_stream_2' !in app.providers.feishu.buffers
	assert 'om_other' in app.providers.feishu.buffers
	assert 'codex:task_stream_clear' !in app.providers.codex.runtime.stream_map
}
