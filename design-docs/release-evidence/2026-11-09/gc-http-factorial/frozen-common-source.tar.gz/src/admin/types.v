module admin

import json2 as json
import os

// ── Worker admin types ──

pub struct WorkerAdminStatus {
pub:
	id                int
	socket            string
	alive             bool
	pid               int
	rss_kb            i64
	draining          bool
	inflight_requests i64
	served_requests   i64
	restart_count     int
	next_retry_ts     i64
}

pub struct WorkerPoolAdminStatus {
pub:
	worker_autostart    bool
	worker_pool_size    int
	worker_rr_index     int
	worker_max_requests int
	worker_sockets      []string
	workers             []WorkerAdminStatus
}

pub struct WorkerAdminErrorResponse {
pub:
	error string
}

pub struct WorkerAdminRestartSingleResponse {
pub:
	ok     bool
	mode   string
	worker WorkerAdminStatus
}

pub struct WorkerAdminRestartAllResponse {
pub:
	ok        bool
	mode      string
	restarted int
}

// ── General admin response types ──

pub struct AdminErrorResponse {
pub:
	error string
}

pub struct AdminRestartSingleResponse {
pub:
	ok     bool
	mode   string
	worker WorkerAdminStatus
}

pub struct AdminRestartAllResponse {
pub:
	ok        bool
	mode      string
	restarted int
	force     bool
}

pub struct AdminFeishuSendResponse {
pub:
	ok         bool
	message_id string @[json: 'message_id']
	error      string
}

// ── Internal admin types ──

pub struct InternalAdminRequest {
pub:
	mode   string
	method string
	path   string
	query  map[string]string
	body   string
}

pub struct InternalAdminResponse {
pub:
	status  int
	headers map[string]string
	body    string
	error   string
}

pub struct AdminQuery {}

pub struct AdminAuth {}

// ── Query helpers ──

pub fn AdminQuery.parse_boolish(raw string) bool {
	return raw.trim_space().to_lower() in ['1', 'true', 'yes', 'on']
}

pub fn AdminQuery.limit(raw string, default_value int, max_value int) int {
	mut value := raw.trim_space().int()
	if value <= 0 {
		value = default_value
	}
	if value > max_value {
		value = max_value
	}
	return value
}

pub fn AdminQuery.offset(raw string) int {
	mut value := raw.trim_space().int()
	if value < 0 {
		value = 0
	}
	return value
}

// ── Auth helpers ──

pub fn AdminAuth.authorized(expected_token string, headers map[string]string, query map[string]string) bool {
	if expected_token == '' {
		return true
	}
	mut token := headers['x-vhttpd-admin-token']
	if token == '' {
		token = query['admin_token'] or { '' }
	}
	return token == expected_token
}

// ── Internal admin socket helpers ──

pub fn AdminState.default_socket() string {
	return '/tmp/vhttpd_admin_${os.getpid()}.sock'
}

pub fn AdminState.default_socket_for(label string) string {
	safe_label := AdminState.sanitize_socket_label(label)
	if safe_label == '' {
		return AdminState.default_socket()
	}
	return '/tmp/vhttpd_admin_${os.getpid()}_${safe_label}.sock'
}

pub fn AdminState.sanitize_socket_label(raw string) string {
	if raw.trim_space() == '' {
		return ''
	}
	mut out := []u8{}
	for ch in raw.bytes() {
		if (ch >= `a` && ch <= `z`) || (ch >= `A` && ch <= `Z`) || (ch >= `0` && ch <= `9`) {
			out << ch
			continue
		}
		if ch in [`-`, `_`, `.`, `:`] {
			out << `_`
		}
	}
	if out.len == 0 {
		return ''
	}
	return out.bytestr()
}

// ── Path normalization ──

fn normalize(raw string) string {
	if raw.len == 0 {
		return '/'
	}
	if raw.starts_with('/') {
		return raw
	}
	return '/${raw}'
}

pub fn InternalAdminRequest.normalize_admin_path(raw string) string {
	mut path := normalize(raw)
	if path == '/admin' {
		return '/'
	}
	if path.starts_with('/admin/') {
		path = path.all_after('/admin')
		if path == '' {
			return '/'
		}
	}
	return path
}

pub fn InternalAdminRequest.normalize_gateway_path(raw string) string {
	mut path := normalize(raw)
	if path == '/gateway' {
		return '/'
	}
	if path.starts_with('/gateway/') {
		path = path.all_after('/gateway')
		if path == '' {
			return '/'
		}
	}
	return path
}

// ── Response builders ──

pub fn InternalAdminResponse.json(body string) InternalAdminResponse {
	return InternalAdminResponse{
		status:  200
		headers: {
			'content-type': 'application/json; charset=utf-8'
		}
		body:    body
	}
}

pub fn InternalAdminResponse.error(status int, message string) InternalAdminResponse {
	return InternalAdminResponse{
		status:  status
		headers: {
			'content-type': 'application/json; charset=utf-8'
		}
		body:    json.encode({
			'error': message
		}, escape_unicode: true, time_as_unix: true)
		error:   message
	}
}

pub fn InternalAdminResponse.bad_request(errmsg string) InternalAdminResponse {
	return InternalAdminResponse.error(400, errmsg)
}

// ── Admin state configuration ──

// AdminState configures the internal admin API server.
pub struct AdminState {
pub mut:
	internal_socket string
	on_data_plane   bool
	token           string
}
